/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** defines
*/

#ifndef DEFINES_H_
#define DEFINES_H_

#define SUCCESS_RETURN 0

#endif /* !DEFINES_H_ */
