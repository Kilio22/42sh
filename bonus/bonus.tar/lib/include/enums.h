/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** enums
*/

#ifndef ENUMS_H_
#define ENUMS_H_

enum fd_save_indexes {
    SAVE_STDIN,
    SAVE_STDOUT,
    SAVE_STDERR,
    FD_SAVE_NB
};

#endif /* !ENUMS_H_ */
