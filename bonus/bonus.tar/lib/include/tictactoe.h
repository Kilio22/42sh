/*
** EPITECH PROJECT, 2019
** my.h project
** File description:
** my.h
*/

#ifndef STMP_S
#define STMP_S

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

typedef struct tic_s {
    char p1;
    char p2;
    char **tab;
    int size;
}              tic_t;

//function to create and update board
void create_board(tic_t *game);
char **update_board(char **coord, char **tab, char c);
void display_board(char **tab, int size);

//main game loop
int which_turn(tic_t *game);

//function to display board
void display_board(char **tab, int size);

//functions for players turns
int player_one_turn(char **tab, int size, char c, tic_t *game);
int player_two_turn(char **tab, int size, char c, tic_t *game);
int check_input(char **coord, char **tab, int n);

//functions to check input coordinates
size_t size_coord_first(char *buff);
size_t size_coord_second(char *buff);

//functions to get coordinates
char **write_coord(char *buff);

//function to check if the game is won or not
int check_win(char **tab, int size, char c);

//function to free board
void free_board(tic_t *game);
void free_coord(char **coord);

#endif /* !STMP_S*/