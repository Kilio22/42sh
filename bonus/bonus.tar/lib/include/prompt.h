/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** prompt
*/

#ifndef PROMPT_H_
#define PROMPT_H_
#include <stdlib.h>

enum keys{
    up_arrow,
    down_arrow,
    left_arrow,
    right_arrow,
    suppr,
    backspace,
};

typedef struct prompt_s{
    char *str;
    size_t pos;
}               prompt_t;
int canonical(int which);
char **base_term(char **envp);
char *get_input(char **env);
char *complete_string(char *str, prompt_t *prompt);
int erasing(prompt_t *prompt, char *buffer);
prompt_t *create_prompt(void);
int empty_prompt(prompt_t *prompt, char *buffer);
char *get_arrows(char **keys);
char *return_for_end(prompt_t *prompt, char **keys);
int writing(prompt_t *prompt, char *buffer);
int check_tab(prompt_t *prompt);
int start_command(prompt_t *prompt, char *buffer);
int print_prompt(void);
#endif /* !PROMPT_H_ */
