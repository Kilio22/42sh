/*
** EPITECH PROJECT, 2019
** main project
** File description:
** main
*/

#include "my_string.h"
#include "shell.h"
#include "tictactoe.h"

void free_coord(char **coord)
{
    for (size_t i = 0; i < 3; i++)
        free(coord[i]);
    free(coord);
}

void free_board(tic_t *game)
{
    for (int i = 0; i < game->size; i++)
        free(game->tab[i]);
    free(game->tab);
}

static void print_status(void)
{
    printf("\nBienvenue dans le");
    printf("\033[33;01m MORPION !\033[00m\n");
    printf("Jeu à 2 joueurs\n");
    printf("\nLe but est de remplir 3 cases consécutives : ");
    printf("Horizontalement, Verticalement, ou Diagonalement.\n");
    printf("Le joueur 1 utilise le caractère 'X'\n");
    printf("Le joueur 2 utilise le caractère 'O'\n");
    printf("\nCtrl + D pour quitter pendant la partie\n\n");
}

int my_tictactoe(struct my_shell *shell __attribute__((unused)),
char **av __attribute__((unused)))
{
    tic_t *game = malloc(sizeof(tic_t));

    if (!game)
        return (-1);
    if (system("clear") == -1)
        return -1;
    game->size = 3;
    game->p1 = 'X';
    game->p2 = 'O';
    print_status();
    create_board(game);
    if (which_turn(game) == -1)
        return (0);
    free_board(game);
    free(game);
    return (0);
}