/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** check_win
*/

#include "tictactoe.h"

static int check_hor(char **tab, int size, char c)
{
    int j = 0;

    for (int i = 0; i != size; i++) {
        for (j = 0; j != size && tab[i][j] != ' ' && tab[i][j] != c; j++);
        if (j == size)
            return (1);
    }
    return (0);
}

static int check_ver(char **tab, int size, char c)
{
    int i = 0;

    for (int j = 0; j != size; j++) {
        for (i = 0; i != size && tab[i][j] != ' ' && tab[i][j] != c; i++);
        if (i == size)
            return (1);
    }
    return (0);
}

static int check_diag_topleft(char **tab, int size, char c)
{
    int count = size;
    int i = 0;
    int y = 0;
    int x = 0;

    while ((i != size) && (count > 0)) {
        if (tab[y][x] != ' ' && tab[y][x] != c)
            count--;
        x++;
        y++;
        i++;
    }
    if (count == 0)
        return (1);
    return (0);
}

static int check_diag_botleft(char **tab, int size, char c)
{
    int count = size;
    int i = 0;
    int y = size - 1;
    int x = 0;

    while ((i != size) && (count > 0)) {
        if (tab[y][x] != ' ' && tab[y][x] != c)
            count--;
        x++;
        y--;
        i++;
    }
    if (count == 0)
        return (1);
    return (0);
}

int check_win(char **tab, int size, char c)
{
    if (check_hor(tab, size, c))
        return (1);
    if (check_ver(tab, size, c))
        return (1);
    if (check_diag_topleft(tab, size, c))
        return (1);
    if (check_diag_botleft(tab, size, c))
        return (1);
    return (0);
}