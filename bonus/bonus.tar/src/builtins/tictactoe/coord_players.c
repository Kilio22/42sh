/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** coord_players
*/

#include "tictactoe.h"

size_t size_coord_first(char *buff)
{
    size_t i = 0;

    for (; buff[i] != ',' && buff[i] != '\0'; i++);
    if (buff[i] == '\0')
        return (84);
    return (i);
}

size_t size_coord_second(char *buff)
{
    size_t i = 0;
    size_t count = 0;

    for (; buff[i] != ',' && buff[i] != '\0'; i++);
    if (buff[i] == '\0')
        return (84);
    i++;
    while (buff[i] != '\0' && buff[i] != '\n') {
        count++;
        i++;
    }
    return (count);
}