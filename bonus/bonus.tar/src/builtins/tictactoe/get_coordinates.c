/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** get_coordinates
*/

#include "tictactoe.h"

static char **malloc_tab(char **array, int sizeone, int sizetwo)
{
    array = malloc(sizeof(char *) * 3);
    if (!array)
        exit(84);
    array[0] = malloc(sizeof(char) * (sizeone + 1));
    if (!array[0])
        exit(84);
    array[1] = malloc(sizeof(char) * (sizetwo + 1));
    if (!array[1])
        exit(84);
    return (array);
}

char **write_coord(char *buff)
{
    char **array = NULL;
    int sizeone = size_coord_first(buff);
    int sizetwo = size_coord_second(buff);
    int i = 0;

    if (sizeone == 84 || sizeone == 84)
        return (NULL);
    array = malloc_tab(array, sizeone, sizetwo);
    for (i = 0; i != sizeone; i++)
        array[0][i] = buff[i];
    array[0][i] = '\0';
    for (int j = i + 1, i = 0; i != sizetwo; i++, j++)
        array[1][i] = buff[j];
    array[1][sizetwo] = '\0';
    array[2] = NULL;
    return (array);
}