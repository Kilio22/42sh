/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** handle_board
*/

#include "tictactoe.h"

void display_board(char **tab, int size)
{
    printf("+");
    for (int i = 0; i != size; i++)
        printf("-");
    printf("+\n");
    for (int i = 0; i != size; i++) {
        printf("|");
        printf("%s", tab[i]);
        printf("|\n");
    }
    printf("+");
    for (int i = 0; i != size; i++)
        printf("-");
    printf("+\n");
    return;
}

char **update_board(char **coord, char **tab, char c)
{
    int x = atoi(coord[0]);
    int y = atoi(coord[1]);

    tab[y][x] = c;
    return (tab);
}

void create_board(tic_t *game)
{
    int x = 0;
    int y = 0;

    game->tab = malloc(sizeof(char *) * (game->size + 1));
    if (!game->tab)
        exit(84);
    for (int i = 0; i < game->size; i++)
        game->tab[i] = malloc(sizeof(char) * (game->size + 1));
    for (x = 0; x < game->size; x++) {
        for (y = 0; y < game->size; y++)
            game->tab[x][y] = ' ';
        game->tab[x][y] = '\0';
    }
}