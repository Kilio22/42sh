/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** actions_players
*/

#include "tictactoe.h"

static void free_during(tic_t *game, char *buff)
{
    free_board(game);
    free(buff);
    free(game);
}

int player_one_turn(char **tab, int size, char c, tic_t *game)
{
    int check = 0;
    char *buff = NULL;
    size_t len = 0;
    char **coord = NULL;

    while (check == 0) {
        printf("Tour du joueur 1 > ");
        if (getline(&buff, &len, stdin) == -1) {
            free_during(game, buff);
            printf("\n\n");
            return (-1);
        }
        coord = write_coord(buff);
        check = check_input(coord, tab, size);
        if (check == 0 && coord != NULL)
            free_coord(coord);
    }
    free(buff);
    tab = update_board(coord, tab, c);
    free_coord(coord);
    return (0);
}

int player_two_turn(char **tab, int size, char c, tic_t *game)
{
    int check = 0;
    char *buff = NULL;
    size_t len = 0;
    char **coord = NULL;

    while (check == 0) {
        printf("Tour du joueur 2 > ");
        if (getline(&buff, &len, stdin) == -1) {
            free_during(game, buff);
            printf("\n\n");
            return (-1);
        }
        coord = write_coord(buff);
        check = check_input(coord, tab, size);
        if (check == 0 && coord != NULL)
            free_coord(coord);
    }
    free(buff);
    tab = update_board(coord, tab, c);
    free_coord(coord);
    return (0);
}