/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** players_turn
*/

#include "tictactoe.h"

int which_turn(tic_t *game)
{
    int is_win = 0;

    while (check_win(game->tab, game->size, game->p1) == 0) {
        display_board(game->tab, game->size);
        if (player_one_turn(game->tab, game->size, game->p1, game) == -1)
            return (-1);
        if (check_win(game->tab, game->size, game->p2)) {
            is_win = 1;
            break;
        }
        display_board(game->tab, game->size);
        if (player_two_turn(game->tab, game->size, game->p2, game) == -1)
            return (-1);
    }
    if (is_win == 1)
        printf("\nLe joueur 1 a gagné !\n");
    else
        printf("\nLe joueur 2 a gagné !\n");
    return (0);
}