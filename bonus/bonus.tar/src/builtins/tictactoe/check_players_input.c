/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** check_players_input
*/

#include "tictactoe.h"

int check_input(char **coord, char **tab, int n)
{
    int x;
    int y;

    if (coord == NULL)
        return (0);
    x = atoi(coord[0]);
    y = atoi(coord[1]);
    if (x >= n || y >= n || x < 0 || y < 0 || coord[0][0] < 48 || coord[0][0]
        > 57 || coord[1][0] < 48 || coord[1][0] > 57)
        return (0);
    if (tab[y][x] != ' ')
        return (0);
    return (1);
}