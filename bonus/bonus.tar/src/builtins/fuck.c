/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** fuck
*/

#include <stdio.h>
#include "shell.h"
#include "my_string.h"

int my_fuck(struct my_shell *shell __attribute__((unused)), char **av)
{
    int ac = my_strarraylen(av);

    if (ac != 2) {
        fprintf(stderr, "fuck: invalid number of args.\n");
        return -1;
    }
    if (av[0][0] >= 'a' && av[0][0] <= 'z')
        av[0][0] -= 32;
    if (av[1][0] >= 'a' && av[1][0] <= 'z')
        av[1][0] -= 32;
    printf("%c%s %c%s !! HIHI <3\n", av[1][0], av[0] + 1, av[0][0], av[1] + 1);
    return 0;
}