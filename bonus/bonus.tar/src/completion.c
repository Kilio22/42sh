/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** test2
*/

#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include "prompt.h"
#include "my_string.h"

char **find_complete(char **tab, char *folder, char *str);

char **complete_array(char **tab, char *str, char *folder)
{
    DIR *dir;
    struct dirent *rd;
    size_t i = 0;

    dir = opendir(folder);
    if (!dir)
        return (NULL);
    while ((rd = readdir(dir))) {
        if (strncmp(rd->d_name, str, strlen(str)) == 0)
            i++;
    }
    closedir(dir);
    tab = malloc(sizeof(char *) *(i + 1));
    if (!tab)
        return (NULL);
    tab = find_complete(tab, folder, str);
    return (tab);
}

char *parse_string(char *str)
{
    size_t i = 0;

    for (; str[i] != '\0'; i++);
    for (; str[i] != '/'; i--);
    return (str + i + 1);
}

char *stock_folder(char *str)
{
    size_t i = 0;

    for (; str[i] != '\0'; i++);
    for (; str[i] != '/'; i--);
    i++;
    str[i] = '\0';
    return (str);
}