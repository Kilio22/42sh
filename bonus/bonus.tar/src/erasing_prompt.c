/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** erasing_prompt
*/

#include <unistd.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"
#include "prompt.h"

static int simple_erasing(prompt_t *prompt)
{
    if (prompt->pos == strlen(prompt->str)) {
        write(1, "\10\33[K", 4);
        prompt->str = strndup(prompt->str, strlen(prompt->str) - 1);
        if (!prompt->str)
            return (-1);
        prompt->pos--;
        return (1);
    }
    return (0);
}

static int hard_erasing(prompt_t *prompt)
{
    char *temp = NULL;

    if (prompt->pos == strlen(prompt->str))
        return (0);
    dprintf(1, "\10\33[K%s", prompt->str + prompt->pos);
    for (size_t i = prompt->pos; i < strlen(prompt->str); i++)
        dprintf(1, "\10");
    fflush(stdout);
    temp = strdup(prompt->str + prompt->pos);
    if (!temp)
        return (-1);
    prompt->str[prompt->pos - 1] = '\0';
    prompt->str = my_strcat(prompt->str, temp);
    if (!prompt->str)
        return (-1);
    prompt->pos--;
    return (0);
}

int erasing(prompt_t *prompt, char *buffer)
{
    if (buffer[0] == 127 && prompt->pos > 0
        && prompt->str && strlen(prompt->str) > 0) {
        if (simple_erasing(prompt) == -1)
            return (-1);
        if (hard_erasing(prompt) == -1)
            return (-1);
    }
    return (0);
}
