/*
** EPITECH PROJECT, 2019
** PSU_minishell2_2018
** File description:
** get_prompt
*/

#include <stddef.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include "prompt.h"
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"

char *get_dirname(void)
{
    char current[256];
    char *dirname = getcwd(current, sizeof(current));
    size_t i = 0;

    if (dirname == NULL)
        return (NULL);
    i = strlen(dirname);
    for (; dirname[i] != '/'; i--);
    return (strdup(dirname + i + 1));
}

int print_prompt(void)
{
    char *login = getlogin();
    char *dir = get_dirname();

    if (!login)
        printf("[None@localhost");
    else
        printf("[%s@localhost", login);
    if (!dir)
        printf("Nowhere]$ ");
    else
        printf("%s]$ ", dir);
    fflush(stdout);
    return (0);
}