/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** prepare_tab_prompt
*/
#include <unistd.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"
#include "prompt.h"

static ssize_t find_whereami(prompt_t *prompt)
{
    size_t i = 0;
    size_t j = 0;
    size_t whereami = 0;
    bool done = false;

    if (!prompt->str || prompt->str[0] == '\0')
        return (-1);
    for (; prompt->str[i] != '\0'; i++) {
        if (prompt->pos == i + 1) {
            whereami = (j == 0) ? 0 : j;
            done = true;
        }
        if (prompt->str[i] == ' ')
            j++;
    }
    if (!done)
        return (-1);
    return (whereami);
}

static size_t find_start(char *str, char *buffer)
{
    size_t i = 0;
    bool bin = false;

    if (strncmp(str, "./", 2) == 0) {
        str += 2;
        bin = true;
    }
    while (buffer[i] != '\0' && str[i] != '\0') {
        if (strncmp(buffer, str, i) != 0)
            break;
        i++;
    }
    if (bin)
        str -= 2;
    return (i);
}

int check_tab(prompt_t *prompt)
{
    char **tab = my_str_towordarray(prompt->str, " ");
    ssize_t whereami = find_whereami(prompt);
    char *str = NULL;
    size_t i = 0;

    if (!tab || whereami == -1 || my_strarraylen(tab) <= 0)
        return (0);
    str = complete_string(tab[whereami], prompt);
    if (!str)
        return (0);
    if (whereami != -1 && str) {
        i = find_start(tab[whereami], str);
        writing(prompt, str + i);
    }
    free(str);
    for (size_t i = 0; tab[i]; i++)
        free(tab[i]);
    free(tab);
    return (0);
}