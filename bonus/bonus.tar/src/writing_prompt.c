/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** writing_prompt
*/

#include <unistd.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"
#include "prompt.h"

static int writing_at_end(prompt_t *prompt, char *buffer)
{
    if (prompt->pos != strlen(prompt->str))
        return (0);

    prompt->str = my_strcat_nofree(prompt->str, buffer);
    for (size_t i = 0; buffer[i] != '\0'; i++) {
        if (buffer[1] == '\0') {
            write(1, buffer, 1);
            break;
        }
        write (1, buffer + i, 1);
    }
    if (!prompt->str)
        return (-1);
    prompt->pos += strlen(buffer);
    return (1);
}

static int writing_inside(prompt_t *prompt, char *buffer)
{
    char *temp = NULL;

    if (prompt->pos == strlen(prompt->str))
        return (0);
    dprintf(1, "%s%s", buffer, prompt->str + prompt->pos);
    for (size_t i = prompt->pos; i < strlen(prompt->str); i++)
        dprintf(1, "\10");
    fflush(stdout);
    temp = my_strdup(prompt->str + prompt->pos);
    if (!temp)
        return (-1);
    prompt->str[prompt->pos] = '\0';
    prompt->pos += strlen(buffer);
    prompt->str = my_strcat(prompt->str, buffer);
    if (!prompt->str)
        return (-1);
    prompt->str = my_strcat(prompt->str, temp);
    if (!prompt->str)
        return (-1);
    return (0);
}

int writing(prompt_t *prompt, char *buffer)
{
    if (!prompt->str) {
        if (start_command(prompt, buffer) == -1)
            return (-1);
        return (0);
    }
    if (writing_at_end(prompt, buffer) == -1)
        return (-1);
    if (writing_inside(prompt, buffer) == -1)
        return (-1);
    return (0);
}
