/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** start_prompt
*/
#include <unistd.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"
#include "prompt.h"

int start_command(prompt_t *prompt, char *buffer)
{
    if (!prompt->str) {
        prompt->str = malloc(sizeof(char) * (2));
        if (!prompt->str)
            return (-1);
        prompt->str[0] = buffer[0];
        prompt->str[1] = '\0';
        prompt->pos = 1;
        write(1, buffer, 1);
        return (1);
    }
    return (0);
}

prompt_t *create_prompt(void)
{
    prompt_t *prompt = malloc(sizeof(prompt_t));

    if (!prompt)
        return (NULL);
    prompt->pos = 0;
    prompt->str = NULL;
    return (prompt);
}

int empty_prompt(prompt_t *prompt, char *buffer)
{
    if (!prompt->str && buffer[0] == '\n') {
        prompt->str = malloc(sizeof(char) * (1));
        if (!prompt->str)
            return (-1);
        prompt->str[0] = '\0';
        return (1);
    }
    return (0);
}

char *get_arrows(char **keys)
{
    char buffer[3];
    char save = 0;
    char *temp = NULL;

    buffer[2] = '\0';
    for (size_t i = 0; i < 2; i++) {
        read(0, &save, 1);
        buffer[i] = save;
    }
    temp = strdup(buffer);
    if (!temp)
        return (NULL);
    for (size_t i = 0; keys[i] != NULL; i++) {
        if (keys[i][strlen(keys[i]) - 1] == buffer[1])
            return (strdup(keys[i]));
    }
    return (temp);
}

char *return_for_end(prompt_t *prompt, char **keys)
{
    char *temp = NULL;

    if (prompt->str) {
        temp = strdup(prompt->str);
        write(1, "\n", 1);
        free(prompt->str);
    }
    free(prompt);
    if (canonical(2) == -1)
        return (NULL);
    if (!isatty(0))
        *my_strchrnul(temp, '#') = '\0';
    if (!keys)
        return (temp);
    for (size_t i = 0; keys[i]; i++)
        free(keys[i]);
    free(keys);
    return (temp);
}
