/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** read_input
*/

#include <term.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <unistd.h>
#include <ncurses.h>
#include <string.h>
#include <termios.h>
#include <signal.h>
#include <sys/types.h>
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"
#include "prompt.h"

int canonical(int which)
{
    struct termios newT;
    static struct termios oldT;

    if (!isatty(STDIN_FILENO))
        return (0);
    if (which == 1) {
        if (tcgetattr(1, &oldT) != 0)
            return (-1);
        newT = oldT;
        newT.c_lflag &= ~(ECHO);
        newT.c_lflag &= ~(ICANON);
        if (tcsetattr(1, TCSAFLUSH, &newT) != 0)
            return (-1);
    }
    else if (which == 2)
        tcsetattr(1, TCSAFLUSH, &oldT);
    return (0);
}

void quit_handler(int signum, siginfo_t *sig_struct, void *point)
{
    (void)sig_struct;
    (void)point;

    if (signum == SIGINT) {
        write(1, "^C", 2);
    }
    if (signum == SIGQUIT)
        return;
}

static int remove_sig_int_quit(void)
{
    struct sigaction act;

    if (sigemptyset(&act.sa_mask) == -1)
        return (-1);
    act.sa_flags = SA_SIGINFO;
    act.sa_sigaction = quit_handler;
    if (sigaction(SIGQUIT, &act, NULL) == -1)
        return (-1);
    if (sigaction(SIGINT, &act, NULL) == -1)
        return (-1);
    return (0);
}

static char **find_keys_sequence(void)
{
    char **keys = malloc(sizeof(char *) * (6));

    if (!keys)
        return (NULL);
    keys[5] = NULL;
    keys[up_arrow] = tigetstr("kcuu1");
    keys[down_arrow] = tigetstr("kcud1");
    keys[left_arrow] = tigetstr("kcub1");
    keys[right_arrow] = tigetstr("kcuf1");
    keys[suppr] = tigetstr("kdch1");
    for (int i = 0; keys[i]; i++)
        if (keys[i] == NULL)
            return (NULL);
    for (size_t i = 0; keys[i]; i++) {
        if (keys[i][0] == 27)
            keys[i] = my_strcat_nofree("^E", keys[i] + 1);
        if (keys[i] == NULL)
            return (NULL);
    }
    return (keys);
}

char **base_term(char **envp)
{
    char *term = NULL;
    ssize_t ret = 0;
    int err = 0;
    char **keys = NULL;

    for (size_t i = 0; envp[i]; i++)
        if (my_strncmp(envp[i], "TERM=", 5) == 0)
            term = my_strdup(envp[i] + 5);
    if (term == NULL)
        return (NULL);
    ret = setupterm(term,  1, &err);
    if (ret == -1 || canonical(1) == -1)
        return (NULL);
    if (remove_sig_int_quit() == -1)
        return (NULL);
    keys = find_keys_sequence();
    free(term);
    if (!keys)
        return (NULL);
    return (keys);
}