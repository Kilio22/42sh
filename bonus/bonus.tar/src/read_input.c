/*
** EPITECH PROJECT, 2019
** PSU_42sh_2018
** File description:
** read_input
*/

#include <unistd.h>
#include <ncurses.h>
#include <string.h>
#include <stdlib.h>
#include "my.h"
#include "my_stdio.h"
#include "my_string.h"
#include "prompt.h"

static void make_arrows(size_t keys, prompt_t *prompt)
{
    if (prompt->str && strlen(prompt->str) > 0
        &&  keys == left_arrow && prompt->pos > 0) {
        write(1, "\10", 1);
        prompt->pos--;
    }
    else if (prompt->str && keys == right_arrow
        && prompt->pos != strlen(prompt->str)) {
        write(1, prompt->str + prompt->pos, 1);
        prompt->pos++;
    }
    else
        return;
}

static int special_chars(prompt_t *prompt, char *buffer, char **keys)
{
    if (erasing(prompt, buffer) == -1)
        return (-1);
    if (empty_prompt(prompt, buffer) == -1)
        return (-1);
    for (size_t i = 0; keys[i] != NULL; i++) {
        if (strcmp(keys[i], buffer) == 0) {
            make_arrows(i, prompt);
            return (1);
        }
    }
    if (buffer[0] == 9 && check_tab(prompt) == -1)
        return (-1);
    if (buffer[0] >= 32 && buffer[0] < 127) {
        if (writing(prompt, buffer) == -1)
            return (-1);
        return (1);
    }
    return (0);
}

static char *buff_end_normal(char *buffer)
{
    char *temp = NULL;

    if (!buffer)
        return (NULL);
    if (buffer[0] == '\4') {
        putchar('\n');
        return (NULL);
    }
    buffer[1] = '\0';
    temp = strdup(buffer);
    if (!temp)
        return (NULL);
    return (temp);
}

static char *get_buffer(char **keys)
{
    ssize_t reader = 0;
    char buffer[4] = {0};
    char *temp = NULL;

    reader = read(0, buffer, 1);
    if (reader <= 0 || buffer[0] == '\4' || buffer[0] != 27) {
        temp = buff_end_normal(buffer);
        if (!temp)
            return (NULL);
        return (temp);
    }
    temp = get_arrows(keys);
    if (!temp)
        return (NULL);
    return (temp);
}

char *get_input(char **env)
{
    char *buffer = NULL;
    char **keys = base_term(env);
    prompt_t *prompt = create_prompt();

    if (!keys || !prompt)
        return (return_for_end(prompt, keys));
    for (char save; 1;) {
        buffer = get_buffer(keys);
        if (!buffer)
            return (return_for_end(prompt, keys));
        save = buffer[0];
        if (special_chars(prompt, buffer, keys) == -1)
            return (return_for_end(prompt, keys));
        if (save == '\n')
            break;
    }
    return (return_for_end(prompt, keys));
}