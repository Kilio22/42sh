/*
** EPITECH PROJECT, 2019
** tictactoe
** File description:
** test
*/

#include <dirent.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include "prompt.h"
#include "my_string.h"
char *parse_string(char *str);
char **complete_array(char **tab, char *str, char *folder);
char *stock_folder(char *str);

int check_params(char *str)
{
    int count = 0;

    for (size_t i = 0; str[i] != '\0'; i++) {
        if (str[i] == '/')
            count++;
    }
    return (count);
}

char **find_complete(char **tab, char *folder, char *str)
{
    DIR *dir;
    struct dirent *rd;
    size_t i = 0;

    dir = opendir(folder);
    if (!dir)
        return (NULL);
    while ((rd = readdir(dir))) {
        if (strncmp(rd->d_name, str, strlen(str)) == 0
        && rd->d_name[0] != '.') {
            tab[i] = strdup(rd->d_name);
            i++;
        }
    }
    tab[i] = NULL;
    closedir(dir);
    return (tab);
}

char **fill_array(char **tab, char *str)
{
    DIR *dir;
    struct dirent *rd;
    size_t i = 0;

    dir = opendir(".");
    if (!dir)
        return (NULL);
    while ((rd = readdir(dir))) {
        if (strncmp(rd->d_name, str, strlen(str) && rd->d_name[0] != '.') == 0)
            i++;
    }
    closedir(dir);
    tab = malloc(sizeof(char *) * (i + 1));
    if (!tab)
        return (NULL);
    tab = find_complete(tab, ".", str);
    return (tab);
}

char **receive_string(char *str, char **tab)
{
    char *dest = NULL;
    int i = 0;

    i = check_params(str);
    if (i == 0)
        tab = fill_array(tab, str);
    else {
        dest = strdup(str);
        dest = stock_folder(dest);
        str = parse_string(str);
        tab = complete_array(tab, str, dest);
    }
    free(dest);
    return (tab);
}

char *complete_string(char *str, prompt_t *prompt)
{
    char **result = NULL;
    size_t i = 0;

    if (str == NULL)
        return NULL;
    result = receive_string(str, result);
    for (; result[i] != NULL; i++);
    if (i == 1)
        return (result[i - 1]);
    else {
        printf("\n");
        for (size_t j = 0; result[j] != NULL; j++)
            printf("%s\n", result[j]);
        print_prompt();
        write(1, prompt->str, strlen(prompt->str));
        return (NULL);
    }
}